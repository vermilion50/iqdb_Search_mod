var id = chrome.contextMenus.create({"title": "Search Bing for image", "contexts":"image",
                                         "id": "context" + "image"});  

// The click event
chrome.contextMenus.onClicked.addListener(onClickHandler);

// The onClicked callback function.
function onClickHandler(info, tab) 
{
  var img2 = info.srcUrl; //stores the URL of the clicked object
  var url2 = "http://www.bing.com/images/searchbyimage?FORM=IRSBIQ&cbir=sbi&imgurl=" + encodeURIComponent(img2);  //combines the Bing query url with the linked image
  window.open(url2, '_blank'); //opens new IQDB tab with proper URL
};
