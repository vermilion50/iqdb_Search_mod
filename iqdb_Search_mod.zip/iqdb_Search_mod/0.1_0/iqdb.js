// Set up context menu at install time.
chrome.runtime.onInstalled.addListener(function() 
{
  var context = "image";
  var title = "Search IQDB for image";
  var id = chrome.contextMenus.create({"title": title, "contexts":[context],
                                         "id": "context" + context});  
});

// The click event
chrome.contextMenus.onClicked.addListener(onClickHandler);

// The onClicked callback function.
function onClickHandler(info, tab) 
{
  var img = info.srcUrl; //stores the URL of the clicked object
  var url = "http://iqdb.org/?url=" + encodeURIComponent(img);  //combines the IQDB query url with the linked image
  window.open(url, '_blank'); //opens new IQDB tab with proper URL
};

chrome.browserAction.onClicked.addListener(function(activeTab)
{
  var newURL = "http://iqdb.org";
  chrome.tabs.create({ url: newURL });
});

