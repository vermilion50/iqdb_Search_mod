// Set up context menu at install time.
chrome.runtime.onInstalled.addListener(function() 
{
  var context = "image";
  var title = "Search IQDB for image";
  var id = chrome.contextMenus.create({"title": title, "contexts":[context],
                                         "id": "context" + context});  
});

// The click event
chrome.contextMenus.onClicked.addListener(onClickHandler);


function is_image_basic(url) {
		try {
			// 4 секции разделены знаком "/", 5-ая содержит параметры
			return /^(https:\/\/[^.]*\.googleusercontent\.com\/([^/]+\/){4})[^/]+\/.*/ui.exec(url)[1] + 's0/';
		} catch (err) {
			return false;
		}
	}

	function is_image_proxy(url) {
		try {
			// Иногда содержит /proxy/, а иногда нет, всегда отделяется от параметров знаком "="
			return /^https:\/\/[a-z0-9-]*\.googleusercontent\.com\/[^=]+=/ui.exec(url)[0] + 's0';
		} catch (err) {
			return false;
		}
	}
	
// The onClicked callback function.
function onClickHandler(info, tab) 
{
  var img = info.srcUrl; //stores the URL of the clicked object 
  var image_url = is_image_basic(img);
  if (image_url === false) { image_url = is_image_proxy(src); }
  var url = "http://iqdb.org/?url=" + encodeURIComponent(image_url);  //combines the IQDB query url with the linked image
  window.open(url, '_blank'); //opens new IQDB tab with proper URL
};

chrome.browserAction.onClicked.addListener(function(activeTab)
{
  var newURL = "http://iqdb.org";
  chrome.tabs.create({ url: newURL });
});

